﻿
// translatorDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "translator.h"
#include "translatorDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}



// CtranslatorDlg 对话框



CtranslatorDlg::CtranslatorDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TRANSLATOR_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CtranslatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_JsonEdit, JE);
	DDX_Control(pDX, IDC_HexEdit, HE);
	DDX_Control(pDX, IDC_SS, SSE);
	DDX_Control(pDX, IDC_DS, DSE);
	DDX_Control(pDX, IDC_DT, DTE);
	DDX_Control(pDX, IDC_PS, PSE);
	DDX_Control(pDX, IDC_MV, MVE);
	DDX_Control(pDX, IDC_FID, FIDE);
}

BEGIN_MESSAGE_MAP(CtranslatorDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_Inc, &CtranslatorDlg::OnBnClickedInc)
	ON_BN_CLICKED(IDC_Json, &CtranslatorDlg::OnBnClickedJson)
	ON_BN_CLICKED(IDC_Pop, &CtranslatorDlg::OnBnClickedPop)
END_MESSAGE_MAP()


// CtranslatorDlg 消息处理程序

BOOL CtranslatorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CtranslatorDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CtranslatorDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CtranslatorDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


#include<string>
using namespace std;


void CtranslatorDlg::OnBnClickedInc(){
	Variable var;
	CString cstr;
	SSE.GetWindowTextW(cstr);
	var.StartSlot = cstr.GetString();
	DSE.GetWindowTextW(cstr);
	var.DataSize = cstr.GetString();
	DTE.GetWindowTextW(cstr);
	var.DataType = cstr.GetString();
	PSE.GetWindowTextW(cstr);
	var.PackageStart = cstr.GetString();
	MVE.GetWindowTextW(cstr);
	var.MapValue = cstr.GetString();
	vars.push_back(var);
	OnBnClickedJson();
}



#include<map>
map<wchar_t, int> cti({ 
	{L'0', 0}, {L'1', 1}, {L'2', 2}, {L'3', 3}, {L'4', 4}, {L'5', 5}, {L'6', 6}
	, {L'7', 7} , {L'8', 8} , {L'9', 9} , {L'a', 10} , {L'b', 11} , {L'c', 12} 
	, {L'd', 13} , {L'e', 14} , {L'f', 15} }
);
void CtranslatorDlg::OnBnClickedJson(){
	CString  cstr;
	FIDE.GetWindowTextW(cstr);
	wstring json = cstr.GetString();
	if (json[0] == L'0') {
		LONGLONG id = 0;
		for (int i = 2;i < json.length();i++) {
			id = id * 16 + cti[json[i]];
		}
		json = to_wstring(id);
	}
	json.push_back('|');
	json += wstring(L"[");

	for (int i = 0;i < vars.size();i++) {
		Variable var = vars[i];
		json += wstring(L"\r\n\t{");
		json += wstring(L"\r\n\t\t\"StartSlot\": ") + L"\"0x" + var.StartSlot + L"\""+L",";
		json += wstring(L"\r\n\t\t\"PackageStart\": ") + var.PackageStart + L",";
		json += wstring(L"\r\n\t\t\"DataSize\": ") + var.DataSize + L",";
		json += wstring(L"\r\n\t\t\"DataType\": ") + var.DataType + L",";
		json += wstring(L"\r\n\t\t\"SubValueType\": ") + L"\"" + var.MapValue + L"\"";
		json +=wstring(L"\r\n\t}");
		if (i != vars.size() - 1) {
			json += wstring(L",");
		}
	}
	json += wstring(L"\r\n]");
	JE.SetWindowTextW(json.c_str());

	wstring hex = L"0x0000000011";
	const wchar_t hexs[] = { '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f' };
	for (wchar_t ch : json) {
		hex.push_back(hexs[ch / 16]);
		hex.push_back(hexs[ch % 16]);
	}
	HE.SetWindowTextW(hex.c_str());
}


void CtranslatorDlg::OnBnClickedPop(){	
	if (vars.size() > 0) { 
		vars.pop_back();
		OnBnClickedJson();
	}
}
